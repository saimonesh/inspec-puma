title 'Puma server config'
# encoding:utf-8
# Copyright 2018, SaiMonesh C S
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# you may obtain a copy of this document at
# https://github.com/saimonesh/inspec-puma
#
#
# Unless required by applicable law or agreed to in writing,software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# author: SaiMonesh C S



#OS SPECIFICATIONS
 OS_NAME =os[:name]
 OS_FAMILY = os[:family]
 OS_VERSION = os[:release]
 OS_ARCH =os[:arch]
 $config_path='/home/saimonesh/appname/config'
  
#RUBY SPECIFICATIONS
RUBY_SPEC =command('ruby -v').stdout

if OS_NAME =='ubuntu' && OS_FAMILY == 'debian' && OS_VERSION =='17.04' && OS_ARCH =='x86_64' &&
RUBY_SPEC == "ruby 2.3.3p222 (2016-11-21) [x86_64-linux-gnu]\n"
then 


control "puma" do
   impact 1.0
   	title "Rails checking"
   		desc "Checking rails installation and version"
			describe gem('rails') do 							#checking rails version
 				it { should be_installed }
 				its('version') { should eq '5.1.4' }
				end
	end



control "puma_install" do
   impact 1.0
   	title "Puma checking"
   		desc "Checking Puma installed and running sucessfully"
			describe systemd_service('puma') do						#checking whether puma installed,enabled,running
  				it { should be_installed }
  				it { should be_enabled }
  				it { should be_running }
			end
	end
 			describe host('localhost', port: 9292, protocol: 'tcp') do                 #checking host availability
      				it { should be_reachable }
      				it { should be_resolvable }
        end  



control "puma_config" do
   impact 1.0
   	title "permissions checking"
   		desc "Checking permissions for puma.conf"
 
 			describe file('/etc/init/puma.conf') do                             #checking puma.conf file access permissions located at /etc
      				it { should be_owned_by 'root' }
           			it { should be_grouped_into 'root' }
           			it { should be_readable.by('owner') }
           			it { should be_writable.by('owner') }
           			it { should_not be_executable.by('owner') }
           			it { should be_readable.by('group') }
          			it { should_not be_writable.by('group') }
           			it { should_not be_executable.by('group') }
           			it { should be_readable.by('others') }
           			it { should_not be_writable.by('others') }
           			it { should_not be_executable.by('others') }
        			end
     			end


control "port_check" do
   impact 1.0
   	title "Port checking"
   		desc "Checking ports and protocols associated with it"
   			describe port(9292) do                                                     #port and protocols checking
      				it { should be_listening }
      				its('protocols') { should cmp 'tcp' }                                   
      				its('protocols') { should cmp 'http'}
      				its('protocols') { should include 'ftp'}
      				its('processes') { should include 'ssh'} 
     				end
			describe host('127.0.0.0', port: 9292, protocol: 'tcp') do
	  			it { should be_resolvable }
	  			its('ipaddress') { should cmp '127.0.0.0' }
  				end  
 			describe ssl(port: 631) do
  				it { should be_enabled }
 				its('ciphers') { should_not eq '/rc4/i' }
  				end
			end



control "port_conf" do
   impact 1.0
   	title "Checking configuration settings of puma"
   		desc "Checking default configurations of puma"
			describe file('/var/lib/gems/2.3.0/gems/puma-3.11.2/lib/puma/configuration.rb') do        #checking default configuration files for puma
 				it { should exist }
 				its('content'){should match 'DefaultTCPHost = "0.0.0.0"'}
				its('content'){should match 'DefaultTCPPort = 9292'}
				its('content'){should match 'DefaultWorkerTimeout = 60'}
				its('content'){should match 'DefaultWorkerShutdownTimeout = 30'}
				its('content'){should match ':min_threads => 0'}
				its('content'){should match ':max_threads => 16'}
    				end
			end
service='/etc/systemd/system/puma.service'



control "service_permission" do
   impact 1.0
   	title "Permission checking for service"
   		desc "checking permission settings for puma.service"
			describe file(service) do
	
    				it {should be_file}
    				it { should be_owned_by 'root' }					#checking permission settings for puma.service
    				it { should be_grouped_into 'root' }
    				it { should  be_readable.by('others') }
    				it { should_not be_writable.by('others') }
    				it { should_not be_executable.by('others') }
  						 end
				end



control "service_config" do
   impact 1.0
   	title "default service config"
   		desc "checking the default configuration for puma.service"
			describe file(service) do
				its ('content') { should match 'User=root'}					#checking default configuration values for puma.service
				its ('content'){ should match 'WorkingDirectory=/home/saimonesh/appname'}
				its ('content'){ should match 'ExecStart=/usr/local/bin/puma -C'+ $config_path+'/puma.rb'}
   					end
			end
nginx_path      = '/etc/nginx'
nginx_conf      = File.join(nginx_path, 'nginx.conf')
nginx_confd     = File.join(nginx_path, 'conf.d')
nginx_enabled   = File.join(nginx_path, 'sites-enabled')
nginx_available = File.join(nginx_path, 'sites-available')
nginx_default   = File.join(nginx_available, 'default')


# 'options' to help the usage of 'parse_config_file' inspec resource
options = {
  assignment_regex: /^\s*([^:]*?)\s*\ \s*(.*?)\s*;$/
}



control "NGINX" do
   impact 1.0
   	title "default service config"
   		desc "checking the default configuration for puma.service"
			describe parse_config_file(nginx_conf, options) do
    				its('group') { should_not eq 'root' }
  				end

			describe parse_config_file(nginx_default,options) do
         			its('listen') { should eq "80"}
       			end													#checking the default configuration for puma.servic
      			describe file(nginx_conf) do
         			it { should be_owned_by 'root' }
         			it { should be_grouped_into 'root' }
         			it { should  be_readable.by('others') }
         			it { should_not be_writable.by('others') }
         			it { should_not be_executable.by('others') }
        			     	end
     			end



control 'nginx_default' do
  impact 1.0
  	title 'Verify the existane of Nginx default files'							#checking default configuration for nginx
  		desc 'Remove the default nginx config files.'
  			describe file(File.join(nginx_confd, 'default.conf')) do
    				it { should_not be_file }
  			end
     		end



control 'nginx_sites_available_and_nginx_sites_enabled' do
   impact 1.0
	title 'Verify the properties of sites-available and sites-enabled'
		desc 'Checking for default files'
			describe file(File.join(nginx_available,'default'))do
				it { should be_file}
   			end
			describe file(File.join(nginx_enabled, 'default'))do
				its('type') { should cmp 'symlink' }
     				it { should be_symlink }
     			 	it { should be_file }
				it { should_not be_directory }
				it { should be_owned_by 'root' }
				it { should be_grouped_into 'root' }
				it { should  be_readable.by('others') }                                 			 #CHECKING PERMISSIONS FOR THE FILE
				it { should_not be_writable.by('others') }
				it { should_not be_executable.by('others') }
 			end
		end




user=File.open('/etc/hostname','r')
if user
content =user.read
user_name=content.split('-')
system_user=user_name[0]
appname ='/home/saimonesh/appname/config'
puma_rb   =File.join(appname,'puma.rb')								#required paths for configuartion of PUMA

			describe file(puma_rb) do
         			it {should be_file}
         			it { should_not be_owned_by 'root' }
         			it { should_not be_grouped_into 'root' }
         			it { should  be_readable.by('others') }
         			it { should_not be_writable.by('others') }
         			it { should_not be_executable.by('others') }
       			end
     		end


#optimize puma server

control 'ruby_2.0_and_above' do
   impact 5.0
	title 'CHECKING THE VERSION OF RUBY INSTALLED.IF RUBY VERSION >= 2.0 THEN THERE IS A MUCH IMPROVED GARBAGE COLLECTOR THAT ALLOWS TO EXPLOIT COPY-ON-WRITE SEMANTICS.IF RUBY VERSION <2.0 THEN IT BECOMES CRITICAL ON MEMORY TERMS FOR DEPLOYING APPLICATIONS USING PUMA WITH NGINX BECAUSE OF NOT EXPLOITING COPY-ON-WRITE SEMANTIC.'
		desc 'If you are using Ruby 1.9, you should seriously consider switching to Ruby 2.0.Ruby 1.9 does not implement Forking and Copy-on-Write (CoW).More accurately, the garbage collection implementation of Ruby 1.9 does not make this possible.Ruby 2.0 fixes this, and can now exploit CoW.'
			describe command('ruby -v')do
				its ('stdout') {should eq "ruby 2.3.3p222 (2016-11-21) [x86_64-linux-gnu]\n"}
				its ('stderr') {should eq ''}
				its ('exit_status'){should eq 0}
  			 end 
		end




#Currently Puma Auto Tune will optimize the number of workers (processes) based on RAM.

#Run Puma Auto Tune in production under load, or in staging while simulating load with tools like siege, blitz.io, or flood.io for a long enough time and we will compute and set your application numbers to maximize concurrent requests without going over your system limits.

control 'Puma_auto_tune' do
   impact 5.0
	title 'Auto tuning puma for max efficiency'                                                        
		desc 'Currently Puma Auto Tune will optimize the number of workers (processes) based on RAM'
			describe gem('puma_auto_tune') do
  				it { should be_installed }
  				its('version') { should eq '0.0.1' }
      		 end
			describe file($config_path+'/initializers/puma_auto_tune.rb')do
 				it{should exist}
   		 end
			describe file($config_path+'/initializers/puma_auto_tune.rb') do
				it {should exist}
				its('content'){should match 'self.ram           = 512 '}                 
				its('content'){should match 'self.max_workers   = INFINITY'}
				its('content'){should match 'self.frequency     = 10 '}
				its('content'){should match 'self.reap_duration = 90 '}
   		end
			describe file($config_path+'/application.rb')do
				its('content'){should match 'PumaAutoTune.start'}
 		end
	end



#Manual tuning puma



control 'worker_processes' do
   impact 5.0
	title 'This sets the number of worker processes to launch.FOR THE BEST PRACTICES OF PUMA IT IS RECOMMENDED TO HAVE [CPU CORE+1] NUMBER OF WORKER_PROCESSES'
		desc 'It is important to know how much memory does one process take.This is so that you can safely budget the amount of workers, in order not to exhaust the RAM'
			describe file($config_path+'/puma.rb') do
				its ('content') {should match 'workers Integer(ENV["WEB_CONCURRENCY"] || 3)'}          #It is recommended to have cpu core+1
			end
		end



control 'timeout' do
   impact 5.0
	title 'Puma does not terminate on timeout'                                           #puma timeout feature
		desc 'There is no default timeout because Puma will never terminate a request based on time.'
			describe file($config_path+'/puma.rb') do
    				its ('content') {should_not match 'timeout '}
			end
		end



control 'Threads' do
   impact 5.0
	title 'Min and Max threads per worker'                          #increasing the min and max threads per worker
		desc 'It is the main feature of puma app server.By altering the number the min and max number of threads by worker'
			describe file($config_path+'/puma.rb') do
				its ('content') {should match 'threads 5,5'}
			end
		end


control 'Available cores' do
   impact 5.0
	title 'To know the available cores'
			describe command('grep -c processor /proc/cpuinfo') do
				its('stdout'){should match /[0-9]/}					#Checking the available cpu cores
			end
		end
$server_key='/home/saimonesh/Documents/server.key'
			describe key_rsa($server_key) do
  				it { should be_private }
  				it { should be_public }
  				its('public_key') { should match "-----BEGIN RSA PRIVATE KEY-----" }
  				its('key_length') { should eq 2048 }
			end
		end
